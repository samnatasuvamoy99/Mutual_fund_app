from django.db import models

# Create your models here.
class userdata(models.Model):
    full_name=models.CharField(max_length=100)
    email=models.EmailField()
    password=models.CharField(max_length=100)
    dob=models.DateField()
    gender=models.CharField(max_length=100)
    contact=models.IntegerField()
    country=models.CharField(max_length=100)

class Meta:
    db_table="userdata"
