from django.shortcuts import render,redirect
from django.http import HttpResponse
from mutual_bridge.models import userdata
from mutual_bridge.models import *
import os
# Create your views here.
def login(request):
    return render(request,'login.html')
def logout(request):
    return render(request,'logout.html')
def index(request):
    return render(request,'index.html')
def about(request):
    return render(request,'about.html')
def form(request):
    return render(request,'form.html')
def profile(request):
    return render(request,'profile.html')
def reg(request):
     u = userdata()
     u.full_name=request.GET['full_name']
     u.dob=request.GET['dob']
     u.email=request.GET['email']
     u.gender=request.GET['gender']
     u.contact=request.GET['contact']
     u.country=request.GET['country']
     u.password=request.GET['password']
     u.save()
     return render(request,'form.html')

def log(request):
    a=request.GET['email']
    b=request.GET['password']
    if userdata.objects.filter(password=b,email=a):
        return render(request,'index.html')
    else:
        return redirect('../login')

def services(request):
    return render(request,'services.html')

def contact(request):
    return render(request,'contact.html')

def display(request):
    a=userdata.objects.all()
    return render(request,'display.html',{'x':a})

def edit_data(request,id):
    d=userdata.objects.get(id=id)
    return render(request,'edit_data.html',{'x':d})

def edit(request, id):
    d = userdata.objects.get(id=id)
    d.full_name = request.POST['full_name']
    d.dob = request.POST['dob']
    d.email = request.POST['email']
    d.gender = request.POST['gender']
    d.contact = request.POST['contact']
    d.country = request.POST['country']
    d.password = request.POST['password']
    d.save()
    return redirect('../display')

def dele(request,id):
    e=userdata.objects.get(id=id)
    e.delete()
    return redirect('../display')



